#!/bin/bash
Rscript two_dim_easy.R 2
Rscript two_dim_hard.R 4
Rscript wine.R 6
