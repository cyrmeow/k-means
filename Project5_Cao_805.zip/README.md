# k-means
a k-means clustering implementation
